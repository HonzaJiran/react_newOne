import React from 'react';

export class MinerStatus extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      null
    );
  }
}

export default MinerStatus;
