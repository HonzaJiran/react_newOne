import React from 'react';

export class GraphicCardStatus extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      null
    );
  }
}

export default GraphicCardStatus;
